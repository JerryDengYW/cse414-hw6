import sys
from model.Vaccine import Vaccine
from model.Caregiver import Caregiver
from model.Patient import Patient
from model.Appointment import Appointment
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql
import datetime
import random


'''
objects to keep track of the currently logged-in user
Note: it is always true that at most one of currentCaregiver and currentPatient is not null
        since only one user can be logged-in at a time
'''
current_patient = None

current_caregiver = None


def create_patient(tokens):
    # create_patient <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 2: check if the username has been taken already
    if username_exists_patient(username):
        print("Username taken, try again!")
        return

    # check 3: check if password is strong enough
    if not password_checking(password):
        print("Your password isn't strong enough!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the patient
    try:
        patient = Patient(username, salt=salt, hash=hash)
        # save to patient information to our database
        patient.save_to_db()
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_patient(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Patients WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username'] is not None
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def create_caregiver(tokens):
    # create_caregiver <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 2: check if the username has been taken already
    if username_exists_caregiver(username):
        print("Username taken, try again!")
        return

    # check 3: check if password is strong enough
    if not password_checking(password):
        print("Your password isn't strong enough!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the caregiver
    try:
        caregiver = Caregiver(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        caregiver.save_to_db()
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_caregiver(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Caregivers WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username'] is not None
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def password_checking(password):
    if len(password) < 8: return False
    if password.lower() == password or password.upper() == password: return False
    if not any(char.isdigit() for char in password) or password.isdigit(): return False
    if password.find("!") == password.find("@") == password.find("#") == password.find("?") == -1: return False
    return True


def login_patient(tokens):
    # login_patient <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_patient
    if current_patient is not None or current_caregiver is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    patient = None
    try:
        patient = Patient(username, password=password).get()
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if patient is None:
        print("Please try again!")
    else:
        print("Patient logged in as: " + username)
        current_patient = patient


def login_caregiver(tokens):
    # login_caregiver <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_caregiver
    if current_caregiver is not None or current_patient is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    caregiver = None
    try:
        caregiver = Caregiver(username, password=password).get()
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if caregiver is None:
        print("Please try again!")
    else:
        print("Caregiver logged in as: " + username)
        current_caregiver = caregiver


def search_caregiver_schedule(tokens):
    # search_caregiver_schedule <date>
    # check 1: is the user currently log in
    global current_caregiver
    global current_patient
    if current_caregiver is None and current_patient is None:
        print("You have to login in order to check schedule")
        return

    date = tokens[1]

    # check 2: if the date is valid
    date_tokens = date.split("-")
    if len(date_tokens) != 3:
        print("Date format invalid!")
        return
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    try:
        d = datetime.datetime(year, month, day)
    except ValueError:
        print("Input date invalid, you should enter a valid date as mm-dd-yyyy")

    try:
        caregivers = check_available_caregivers(d)
        # check 3: if there are vaccines available
        a_vaccines = get_available_vaccines()
        if len(a_vaccines) == 0: print("No available doses currently")
        # check 4: if the date has no caregiver available
        elif len(caregivers) == 0: print("No available caregiver on given date")
        else:
            print("Available caregivers on given date:")
            for row in caregivers:
                print(row)
            print("Currently available vaccines:")
            for row in a_vaccines:
                print(row["Name"] + " " + str(row["Doses"]))
    except pymssql.Error:
        print("Error occurred when searching caregivers' schedule")


def get_available_vaccines():
    cm = ConnectionManager()
    conn = cm.create_connection()
    result = []

    select_vaccine = "SELECT * FROM Vaccines WHERE Doses > 0"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_vaccine)
        result = cursor.fetchall()
    except pymssql.Error:
        print("Error occurred when checking vaccines")
        cm.close_connection()
    cm.close_connection()
    return result


def reserve(tokens):
    # reserve <date> <vaccine>
    # check 1: if the current logged-in user is a patient
    global current_patient
    if current_patient is None:
        print("Please login as a patient first!")
        return

    date = tokens[1]
    # just to keep as normal since it modify not to lowercase in order to check password
    vaccine = tokens[2].lower()

    # check 2: if the date is available
    date_tokens = date.split("-")
    if len(date_tokens) != 3:
        print("Date format invalid!")
        return
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    try:
        d = datetime.datetime(year, month, day)
    except ValueError:
        print("Input date invalid, you should enter a valid date as mm-dd-yyyy")
    a_caregivers = check_available_caregivers(d)
    if len(a_caregivers) == 0:
        print("There is no available caregivers on the given date")
        return
    # check 3: if the vaccine is available
    vaccines = set()
    for row in get_available_vaccines():
        vaccines.add(row["Name"])
    if vaccine not in vaccines:
        print("There is no required vaccines currently")
        return
    caregiver = a_caregivers[random.randint(0, len(a_caregivers)-1)]
    # check 4: if the patient already have an appointment that day
    if check_exist_app_patient(d, current_patient.username):
        print("You already have an appointment on this date")
        return
    appointmentID = create_appointmentID()
    # check 5: check if the appointmentID is duplicate really little by chance
    if appointmentID_exists_appointment(appointmentID):
        print("Please try again!")
        return
    try:
        appointment = Appointment(appointmentID, caregiver, current_patient.username, vaccine, d)
        appointment.save_to_db()
        print(" *** Appointment created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return
    print("Caregiver: " + caregiver)
    print("AppointmentID " + appointmentID)
    update_doses(vaccine, -1)


def update_doses(vaccine, n):
    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    update_vaccine_availability = "UPDATE vaccines SET Doses = %d WHERE name = %s"
    try:
        doses = get_doses(vaccine)
        cursor.execute(update_vaccine_availability, (doses + n, vaccine))
        conn.commit()
    except pymssql.Error:
        print("Error occurred when updating vaccine availability")
        cm.close_connection()
    cm.close_connection()


def get_doses(vaccine):
    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    update_vaccine_availability = "SELECT Doses FROM Vaccines WHERE name = %s"
    try:
        cursor.execute(update_vaccine_availability, vaccine)
        for row in cursor:
            return row["Doses"]
    except pymssql.Error:
        print("Error occurred when getting vaccine doses")
        cm.close_connection()
    cm.close_connection()


def create_appointmentID():
    id = "#"
    for i in range(12):
        id += str(random.randint(0,9))
    return id


def appointmentID_exists_appointment(id):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_appointment = "SELECT * FROM Appointments WHERE AppointmentID = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_appointment, id)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['AppointmentID'] is not None
    except pymssql.Error:
        print("Error occurred when checking appointmentID")
        cm.close_connection()
    cm.close_connection()
    return False


def check_available_caregivers(d):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_date = "SELECT Username FROM Availabilities WHERE Time = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_date, d)
        caregiver_with_app = get_exist_appointment(d)
        l = []
        result = cursor.fetchall()
        for row in result:
            l.append(row["Username"])
        for user in caregiver_with_app:
            if user in l:
                l.remove(user)
    except pymssql.Error:
        print("Error occurred when checking availablility")
        cm.close_connection()
    cm.close_connection()
    return l


def upload_availability(tokens):
    #  upload_availability <date>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    # check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
    if len(tokens) != 2:
        print("Please try again!")
        return

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    date_tokens = date.split("-")
    # check 3: check if the format is valid
    if len(date_tokens) != 3:
        print("Date format invalid!")
        return
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    try:
        d = datetime.datetime(year, month, day)
        # check 4: if there is an appointment already
        if check_exist_appointment(d, current_caregiver.username):
            print("You already have an appointment on the date")
            return
        current_caregiver.upload_availability(d)
        print("Availability uploaded!")
    except ValueError:
        print("Please enter a valid date!")
    except pymssql.Error as db_err:
        print("Error occurred when uploading availability")


def check_exist_appointment(d, caregiver):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_appointment = "SELECT * FROM Appointments WHERE Time = %s AND CaregiverN = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_appointment, (d, caregiver))
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['AppointmentID'] is not None
    except pymssql.Error:
        print("Error occurred when checking existed appointment")
        cm.close_connection()
    cm.close_connection()
    return False


def check_exist_app_patient(d, patient):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_appointment = "SELECT * FROM Appointments WHERE Time = %s AND PatientN = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_appointment, (d, patient))
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['AppointmentID'] is not None
    except pymssql.Error:
        print("Error occurred when checking existed appointment")
        cm.close_connection()
    cm.close_connection()
    return False


def get_exist_appointment(d):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_appointment = "SELECT CaregiverN FROM Appointments WHERE Time = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_appointment, (d))
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        l = []
        result = cursor.fetchall()
        for row in result:
            l.append(row["CaregiverN"])
    except pymssql.Error:
        print("Error occurred when checking existed appointment")
        cm.close_connection()
    cm.close_connection()
    return l


def cancel(tokens):
    """
    TODO: Extra Credit
    """
    pass


def add_doses(tokens):
    #  add_doses <vaccine> <number>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    #  check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    vaccine_name = str(tokens[1])
    doses = int(tokens[2])
    vaccine = None
    try:
        vaccine = Vaccine(vaccine_name, doses).get()
    except pymssql.Error:
        print("Error occurred when adding doses")

    # check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
    #          table

    if vaccine is None:
        try:
            vaccine = Vaccine(vaccine_name, doses)
            vaccine.save_to_db()
        except pymssql.Error:
            print("Error occurred when adding doses")
    else:
        # if the vaccine is not null, meaning that the vaccine already exists in our table
        try:
            ori_doses = vaccine.available_doses
            # split addition and subtraction here, bug originally
            if doses > 0: vaccine.increase_available_doses(doses)
            elif doses < 0: vaccine.decrease_available_doses(doses)
            else: print("Doses updated!")
        except pymssql.Error:
            print("Error occurred when adding doses")
        cur_doses = vaccine.available_doses
        if (ori_doses != cur_doses): print("Doses updated!")


def show_appointments(tokens):
    # show_appointments
    global current_caregiver
    global current_patient
    # check 1: if the user is a caregiver
    if current_caregiver is not None:
        cm = ConnectionManager()
        conn = cm.create_connection()

        select_appointment = "SELECT AppointmentID, VaccineN, Time, PatientN FROM Appointments WHERE CaregiverN = %s"
        try:
            cursor = conn.cursor(as_dict=True)
            cursor.execute(select_appointment, current_caregiver.username)
            result = cursor.fetchall()
        except pymssql.Error:
            print("Error occurred when checking availablility")
            cm.close_connection()
        cm.close_connection()
        if len(result) == 0: print("You have no appointment yet.")
        else:
            for row in result:
                print(row["AppointmentID"] + " " + row["VaccineN"] + " " + str(row["Time"]) + " " + row["PatientN"])
    # check 2: if the user is a patient
    elif current_patient is not None:
        cm = ConnectionManager()
        conn = cm.create_connection()

        select_appointment = "SELECT AppointmentID, VaccineN, Time, CaregiverN FROM Appointments WHERE PatientN = %s"
        try:
            cursor = conn.cursor(as_dict=True)
            cursor.execute(select_appointment, current_patient.username)
            result = cursor.fetchall()
        except pymssql.Error:
            print("Error occurred when checking availablility")
            cm.close_connection()
        cm.close_connection()
        if len(result) == 0: print("You have no appointment yet.")
        else:
            for row in result:
                print(row["AppointmentID"] + " " + row["VaccineN"] + " " + str(row["Time"]) + " " + row["CaregiverN"])
    else: print("You have to login to check appointments")


def logout(tokens):
    # logout
    global current_patient
    global current_caregiver

    # check if user is currently log in
    if current_patient is None and current_caregiver is None:
        print("You haven't login yet")
    else:
        current_patient = None
        current_caregiver = None
        print("Logout successfully!")


def start():
    stop = False
    while not stop:
        print()
        print(" *** Please enter one of the following commands *** ")
        print("> create_patient <username> <password>")  # //TODO: implement create_patient (Part 1)
        print("> create_caregiver <username> <password>")
        print("> login_patient <username> <password>")  #// TODO: implement login_patient (Part 1)
        print("> login_caregiver <username> <password>")
        print("> search_caregiver_schedule <date>")  #// TODO: implement search_caregiver_schedule (Part 2)
        print("> reserve <date> <vaccine>") #// TODO: implement reserve (Part 2)
        print("> upload_availability <date>")
        print("> cancel <appointment_id>") #// TODO: implement cancel (extra credit)
        print("> add_doses <vaccine> <number>")
        print("> show_appointments")  #// TODO: implement show_appointments (Part 2)
        print("> logout") #// TODO: implement logout (Part 2)
        print("> Quit")
        print()
        response = ""
        print("> Enter: ", end='')

        try:
            response = str(input())
        except ValueError:
            print("Type in a valid argument")
            break

        # in order to check password
        tokens = response.split(" ")
        tokens[0] = tokens[0].lower()
        if len(tokens) > 1: tokens[1] = tokens[1].lower()
        if len(tokens) == 0:
            ValueError("Try Again")
            continue
        operation = tokens[0]
        if operation == "create_patient":
            create_patient(tokens)
        elif operation == "create_caregiver":
            create_caregiver(tokens)
        elif operation == "login_patient":
            login_patient(tokens)
        elif operation == "login_caregiver":
            login_caregiver(tokens)
        elif operation == "search_caregiver_schedule":
            search_caregiver_schedule(tokens)
        elif operation == "reserve":
            reserve(tokens)
        elif operation == "upload_availability":
            upload_availability(tokens)
        elif operation == cancel:
            cancel(tokens)
        elif operation == "add_doses":
            add_doses(tokens)
        elif operation == "show_appointments":
            show_appointments(tokens)
        elif operation == "logout":
            logout(tokens)
        elif operation == "quit":
            print("Thank you for using the scheduler, Goodbye!")
            stop = True
        else:
            print("Invalid Argument")


if __name__ == "__main__":
    '''
    // pre-define the three types of authorized vaccines
    // note: it's a poor practice to hard-code these values, but we will do this ]
    // for the simplicity of this assignment
    // and then construct a map of vaccineName -> vaccineObject
    '''

    # start command line
    print()
    print("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!")

    start()
