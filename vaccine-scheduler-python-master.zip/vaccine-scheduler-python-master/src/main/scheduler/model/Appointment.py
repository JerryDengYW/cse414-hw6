import sys
sys.path.append("../db/*")
from db.ConnectionManager import ConnectionManager
import pymssql

class Appointment:
    def __init__(self, appointmentID, caregiver=None, patient=None, vaccine=None, date=None):
        self.appointmentID = appointmentID
        self.caregiver = caregiver
        self.patient = patient
        self.vaccine = vaccine
        self.date = date


    def save_to_db(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor()

        add_appointments = "INSERT INTO Appointments VALUES (%s, %s, %s, %s, %s)"
        try:
            cursor.execute(add_appointments, (self.appointmentID, self.caregiver, self.patient, self.vaccine, self.date))
            # you must call commit() to persist your data if you don't set autocommit to True
            conn.commit()
        except pymssql.Error as db_err:
            print("Error occurred when inserting Appointments")
            sqlrc = str(db_err.args[0])
            print("Exception code: " + str(sqlrc))
            cm.close_connection()
        cm.close_connection()
